// Using promises/async await/fetch get the random todos from the json placeholder api. And log all the
// completed todos to the console.
// API Endpoint : https://jsonplaceholder.typicode.com/todos


 fetch('https://jsonplaceholder.typicode.com/users')
   .then(res => res.json())
   .then(res => res.map(user => user.username))
   .then(userNames => console.log(userNames));

  async function fetchUsers(endpoint)
   {
    const res = await fetch(endpoint);
    let data = await res.json();
  
    data = data.map(user => user.username);
  
    console.log(data);
  }
  
  fetchUsers('https://jsonplaceholder.typicode.com/users')


  async function fetchUsers(endpoint) {
  const res = await fetch(endpoint);

  if (!res.ok) {
    throw new Error(res.status); // 404
  }

  const data = await res.json();
  return data;
}

fetchUsers('https://jsonplaceholder.typicode.com/usersZZZ')
  .then(data => {
    console.log(data.map(user => user.website));
  })
  .catch(err => console.log('Ooops, error', err.message));