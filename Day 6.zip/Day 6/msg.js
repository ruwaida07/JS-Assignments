// Displaying name by getting input from user

const name = prompt("Enter your name:");
title.innerText +=`Welcome to the page ${name}`;

// Clock function for displaying time

const ctime = document.getElementById('time');
function clock()
{
    let date = new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;
}
setInterval(clock,1000);

// Toggle function for applying dark mode

document .querySelector(".toggleButton") 
.addEventListener("click", toggleDarKMode);
function toggleDarKMode()
 {
   var element = document.body;
   element.classList.toggle("dark-mode");
 }